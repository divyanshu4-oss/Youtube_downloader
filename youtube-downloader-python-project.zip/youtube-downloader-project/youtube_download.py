from tkinter import *
import tkinter as tk
from itertools import count, cycle
from PIL import ImageTk, Image
from pytube import YouTube

root = Tk()
root.geometry('600x400')
root.resizable(0,0)
root.title("youtube video downloader")
root.iconbitmap('youtube.ico')  
root.configure(bg='#40E0D0')
Label(root,text = 'Youtube Video Downloader', font ='arial 20 bold',bg='red').pack()




##enter link
link = StringVar()

Label(root, text = 'Paste Link Here:', font = '"Times New Roman" 15 bold',activebackground="pink").place(x= 210 , y = 60)
link_enter = Entry(root, width = 70,textvariable = link).place(x = 90, y = 90)



#function to download video


def Downloader():
     
    url =YouTube(str(link.get()))
    video = url.streams.first()
    video.download()
    
Label(root, text = 'DOWNLOADED', font = '"Times New Roman" 15 ').place(x= 300 , y = 210)  


Button(root,text = 'DOWNLOAD', font = '"Times New Roman" 15 bold' ,bg = 'pale violet red', padx = 2, command = Downloader).place(x=220,y = 120)
class ImageLabel(tk.Label):
    """
    A Label that displays images, and plays them if they are gifs
    :im: A PIL Image instance or a string filename
    """
    def load(self, im):
        if isinstance(im, str):
            im = Image.open(im)
        frames = []

        try:
            for i in count(1):
                frames.append(ImageTk.PhotoImage(im.copy()))
                im.seek(i)
        except EOFError:
            pass
        self.frames = cycle(frames)

        try:
            self.delay = im.info['duration']
        except:
            self.delay = 100

        if len(frames) == 1:
            self.config(image=next(self.frames))
        else:
            self.next_frame()

    def unload(self):
        self.config(image=None)
        self.frames = None

    def next_frame(self):
        if self.frames:
            self.config(image=next(self.frames))
            self.after(self.delay, self.next_frame)

# Load GIF :
lbl = ImageLabel(root)
lbl.pack()
lbl.load("youtube.gif")
lbl.place(x=1, y = 200,width="600", height="200")



root.mainloop()
